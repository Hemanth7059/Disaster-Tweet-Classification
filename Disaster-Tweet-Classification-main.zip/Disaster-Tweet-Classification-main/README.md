# Disaster-Tweet-Classification
Detection of disasters related tweets with machine learning
The development of new tools has greatly improved our capacity for interpersonal communication. Communities can no longer solely depend on purchasing news from print, radio, and television media. With the emergence of smartphone technology, communities are simply a 'app' away from being able to give or receive information within milliseconds.


Twitter has grown to be a crucial contact tool during emergencies. Smartphones are so common that anyone can instantly report an incident they are witnessing. There will be a number of tweets floating around on Twitter during emergencies. However, it's not always obvious if someone is truly foreseeing a disaster when they speak. A human eye may see it clearly straight away, but a machine may not. We create a machine learning model that determines which disaster-related tweets are genuine and which ones are not.
